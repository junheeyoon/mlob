# __init__.py

from observability import LiveData

__version__ = '1.0.3'
__author__ = 'yoonjh4'

API_HOST = "http://127.0.0.1:9099"
URL = "/ml_ob/api/v1.0/live_data_import"
