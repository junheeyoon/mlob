# __init__.py

from observability import live_data

__version__ = '1.0.1'
__author__ = 'yoonjh4'