# __init__.py

from observability import LiveData

__version__ = '1.0.2'
__author__ = 'yoonjh4'